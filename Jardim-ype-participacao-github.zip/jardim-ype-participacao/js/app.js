document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("#participation-form");
  const feedback = document.querySelector("#form-feedback");
  document.querySelector("#year").textContent = new Date().getFullYear();

  document.querySelectorAll("[data-choice]").forEach(link => {
    link.addEventListener("click", () => {
      const map = {
        voluntario: "Voluntário(a)",
        candidato: "Interesse em candidatura a subsíndico(a)",
        ideia: "Sugestão ou ideia"
      };
      document.querySelector("#tipo").value = map[link.dataset.choice];
    });
  });

  form.addEventListener("submit", async event => {
    event.preventDefault();
    feedback.className = "form-feedback";
    feedback.textContent = "";

    const areas = [...form.querySelectorAll('input[name="areas"]:checked')].map(el => el.value);
    if (!areas.length) {
      feedback.classList.add("error");
      feedback.textContent = "Selecione ao menos uma área de interesse.";
      return;
    }

    if (!window.SUPABASE_URL || !window.SUPABASE_ANON_KEY ||
        !window.supabase || typeof window.supabase.createClient !== "function") {
      feedback.classList.add("error");
      feedback.textContent = "O formulário ainda não está conectado ao banco de dados. Configure o Supabase conforme o README antes de divulgar o link.";
      return;
    }

    const data = Object.fromEntries(new FormData(form).entries());
    data.areas = areas;
    delete data.consentimento;
    data.consentimento_em = new Date().toISOString();

    const client = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
    const { error } = await client.from("participacoes").insert([data]);

    if (error) {
      console.error(error);
      feedback.classList.add("error");
      feedback.textContent = "Não foi possível enviar agora. Confira os dados ou tente novamente mais tarde.";
      return;
    }

    form.reset();
    feedback.classList.add("success");
    feedback.textContent = "Participação enviada com sucesso! Obrigado por contribuir com o Jardim do Ypê.";
  });
});
