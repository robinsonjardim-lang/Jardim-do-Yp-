// Configure este arquivo com os dados do seu projeto Supabase.
// Nunca coloque a chave service_role aqui. Use somente a chave anon/public.
// Enquanto as credenciais estiverem vazias, o formulário não enviará dados.
window.SUPABASE_URL = "";
window.SUPABASE_ANON_KEY = "";
